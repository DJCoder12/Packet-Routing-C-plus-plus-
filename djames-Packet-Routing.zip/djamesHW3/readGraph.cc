#include <string>
#include <iostream>
#include <fstream>
#include <limits>
#include <vector>
#include "readGraph.h"

using namespace std;


int readGraph(ifstream& fin, double**& matrix, string*& vLabels, string**& eLabels)
{
   int numVertices;
   fin >> numVertices;
   int numEdges;
   fin >> numEdges;
   
   cout << numVertices << " " << numEdges << endl;

   vLabels = new string[numVertices];
   for(int i = 0; i < numVertices; i++)
   {
      fin >> vLabels[i];
   }
   
   matrix = new double*[numVertices];
   eLabels = new string*[numVertices];
   for(int i = 0; i < numVertices; i++)
   {
      matrix[i] = new double[numVertices];
      eLabels[i] = new string[numVertices];
      for(int j = 0; j < numVertices; j++)
      {
	 matrix[i][j] = numeric_limits<double>::infinity();
      }
   }
   
   for(int i = 0; i < numVertices; i++)
   {
      matrix[i][i] = 0;
   }

   for(int i = 0; i < numEdges; i++)
   {	 
      int sourceV;
      fin >> sourceV;
      int destV;
      fin >> destV;
      double w;
      fin >> w;
      string l;
      fin >> l;
      
      matrix[sourceV][destV] = w;
      eLabels[sourceV][destV] = l;
   }

   return numVertices;
}

int readGraph(ifstream& fin, int**& adj, double**& weights, int*& lengths, string*& vLabels, string**& eLabels)
{
   int numVertices;
   fin >> numVertices;
   int numEdges;
   fin >> numEdges;
   
   vLabels = new string[numVertices];
   for(int i = 0; i < numVertices; i++)
   {
      fin >> vLabels[i];
   }
   
   adj = new int*[numVertices];
   weights = new double*[numVertices];
   lengths = new int[numVertices];
   eLabels = new string*[numVertices];

   int sourceV;
   fin >> sourceV;
   for(int i = 0; i < numVertices; i++)
   {
      vector<int> tmpAdj;
      vector<double> tmpWeights;
      vector<string> tmpLabels;
   
      lengths[i] = 0;
      while(!fin.eof() && sourceV == i)
      {
	 int destV;
	 fin >> destV;
	 tmpAdj.push_back(destV);
	 double w;
	 fin >> w;
	 tmpWeights.push_back(w);
	 string label;
	 fin >> label;
	 tmpLabels.push_back(label);
	 lengths[i]++;
	 fin >> sourceV;
      }

      adj[i] = new int[lengths[i]];
      weights[i] = new double[lengths[i]];
      eLabels[i] = new string[lengths[i]];
      for(int j = 0; j < lengths[i]; j++)
      {
	 adj[i][j] = tmpAdj[j];
	 weights[i][j] = tmpWeights[j];
	 eLabels[i][j] = tmpLabels[j];
      }
   }

   return numVertices;
}

int readGraph(ifstream& fin, int**& edgeList, double*& weights, int& numEdges, string*& vLabels, string*& eLabels)
{
   int numVertices;
   fin >> numVertices;
   fin >> numEdges;
   

   vLabels = new string[numVertices];
   for(int i = 0; i < numVertices; i++)
   {
      fin >> vLabels[i];
   }

   edgeList = new int*[numEdges];
   weights = new double[numEdges];
   eLabels = new string[numEdges];

   for(int i = 0; i < numEdges; i++)
   {
      int sourceV;
      fin >> sourceV;
      int destV;
      fin >> destV;
      double w;
      fin >> w;
      string l;
      fin >> l;
      
      edgeList[i] = new int[2];
      edgeList[i][0] = sourceV;
      edgeList[i][1] = destV;
      weights[i] = w;
      eLabels[i] = l;
   }

   return numVertices;
}















  //////////////////////////////////////////////////////////////////////////////
  //ORIGINAL CODE 
/*
  //fin is already attached to the file that it wants to read and is capable of reading content based on white space
int readGraph(ifstream& fin, double**& matrix, string*& vLabels, string**& eLabels)
{
  int eCount;
  int vCount;
  string curVertex;
  fin>>vCount;
  fin>>eCount;
  int d1;
  int d2;
  double weight;
  string link;
  matrix= new double*[vCount];//This needs to be an array of arrays
  vLabels=new string [vCount]; // Contains all the vertices in the matrix
  eLabels=new string*[vCount];// contains all the edges in the matrix. LinkNumers
  
  // This for loop should fill your vLabel  
 
  for (int i=0;i<vCount;i++)
    {
      fin>>curVertex;
      vLabels[i]=curVertex;
    }
  //this creates your array of arrays for both matrix and eLabels
  for (int i=0; i<vCount;i++)
    {
      matrix[i]=new double[vCount];
      eLabels[i]=new string[vCount];
      for (int k=0;k<vCount;k++)
	{
	  matrix[i][k]=numeric_limits<double>::infinity();
	  eLabels[i][k]="";
	}
      
    }

  //This will fill both the matrix and the elabel

  // seg fault happens in this loop on the line with setting matrix index to being weight.
  while(!fin.eof())
    {
      //cout<<"I append"<<endl;
      fin>>d1;
      //cout<<"d1 is made"<<endl;
      fin>>d2;
      //cout<<"d2 is made"<<endl;
      fin>>weight;
      //cout<<"weight is a go"<<endl;
      matrix[d1][d2]=weight;
      cout<<"matrix index has been set"<<endl;
      fin>>link;
      //cout<<"link is initialized"<<endl;
      eLabels[d1][d2]=link;
      //cout<<"link is used"<<endl;
     
    }  
 
  cout<<matrix[0][0]<<endl;
  cout<<matrix[0][3]<<endl;
  cout<<matrix[1][2]<<endl;
  cout<<matrix[2][0]<<endl;
  cout<<matrix[2][1]<<endl;
  cout<<matrix[2][3]<<endl;
  
  return vCount;
}









int readGraph(ifstream& fin, int**& adj,double**& weights, int*& lengths,string*& vLabels, string**& eLabels)
{
  
  int eCount;
  int vCount;
  string curVertex;
  fin>>vCount;
  fin>>eCount;
  double tempweight;
  int d1;
  int d2;
  //double ** weight;
  string link;
  //The following should all have an adjusted size based on the how many vertices are adjacent
  adj= new int*[vCount];//This needs to be an array of arrays
  weights=new double*[vCount]; // Contains all the vertices in the matrix
  eLabels=new string*[vCount];// contains all the edges in the matrix. LinkNumers
  vLabels=new string[vCount];
  
  //The following needs to be changed to accomodate for the weights adj and elabels 

  //this creates your array of arrays 
  for (int i=0; i<vCount;i++)
    {
      adj[i]=new int[vCount];
      eLabels[i]=new string[vCount];
      weights[i]=new double[vCount];
      for (int k=0;k<vCount;k++)
	{
	  weights[i][k]=numeric_limits<double>::infinity();
	  eLabels[i][k]="";
	}
    }
  while(!fin.eof())
    {
      fin>>d1;
      fin>>d2;
      fin>>tempweight;
      weights[d1][d2]=tempweight;
      fin>>link;
      eLabels[d1][d2]=link;
    }  
  
  return vCount;
}




int readGraph(ifstream& fin, int**& edgeList, double*& weights,int& numEdges, string*& vLabels, string*& eLabels)

{
  
  cout<<"I started the readGraph3 function"<<endl;
  int eCount;
  int vCount;
  string vertex;
  
  fin>>vCount;
  fin>>eCount;
  int source;
  int dest;
  double weight;
  int edge;
  weights=new double [numEdges];
  vLabels=new string [vCount];
  eLabels=new string [eCount];
  edgeList= new int*[numEdges];
 
  for (int i=0; i<vCount;i++)
    {
      edgeList[i]=new int[2];
    }
  
  for(int j=0;j<vCount;j++)
    {
      fin>>vertex;
      cout<<vertex<<endl;
      vLabels[j]=vertex;
    }

  while(!fin.eof())
    {
      fin>>source;
      fin>>dest;
      cout<<source<<endl;
      cout<<dest<<endl;
      //fin>>weight;
      //matrix[d1][d2]=weight;
      //fin>>link;
      //eLabels[d1][d2]=link;
    }  


  
  for( int k=0;k<numEdges;k++)
    {
      fin>>source;
      cout<<source<<endl;
      fin>>dest;
      cout<<dest<<endl;
      fin>>weight;
      cout<<weight<<endl;
      fin>>edge;
      weights[k]=weight;
      edgeList[k][0]=source;
      edgeList[k][1]=dest;
      eLabels[k]=edge;
    }  
  return 0; 
}
*/
  // return vCount;


