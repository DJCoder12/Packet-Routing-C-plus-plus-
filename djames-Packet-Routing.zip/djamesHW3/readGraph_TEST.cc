#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include "readGraph.h"
using namespace std;

TEST_CASE("TESTING Read Graph")
{
   
  
  SECTION("readGraph")
    {
      
      ifstream fin("graph_network.txt");
      double** matrix;
      string* vLabels;
      string** eLabels;
          
      int vCount=readGraph(fin,matrix,vLabels,eLabels);
      
      //cout<<"The readGraph function happened fine"<<endl;
      REQUIRE(vCount==4);      
      for (int i=0;i<vCount;i++)
	{
	  delete[] matrix[i];
	  delete[] eLabels[i];
	}
       
      delete[] vLabels;
      delete[] eLabels;
      delete[] matrix;
      
    }
   SECTION("readGraph #2")
    {
      ifstream fin("graph_network.txt");
      int** adj;
      double** weights;
      int * lengths;
      string* vLabels;
      string** eLabels;
      
      int vCount=readGraph(fin,adj,weights,lengths,vLabels,eLabels);
      REQUIRE(vCount==4);
      for(int i=0; i<vCount;i++)
	{
	  delete[] adj[i];
	  delete[] weights[i];
	  delete[] eLabels[i];
	}
      delete[] vLabels;
      delete[] adj;
      delete[] weights;
      delete[] eLabels;
      delete[] lengths;
    }
  
  SECTION("readGraph #3")
    {
      ifstream fin("graph_network.txt");
      int** edgeList;
      double* weights;
      int numEdges;
      string* vLabels;
      string* eLabels;
      int vCount=readGraph(fin, edgeList, weights, numEdges, vLabels, eLabels);
      REQUIRE(vCount==4);
      
      for(int i=0; i<numEdges;i++)
	{
	  delete[] edgeList[i];
	}
      delete[] vLabels;
      delete[] eLabels;
      delete[] edgeList;
      delete[] weights;
      
    }
}
