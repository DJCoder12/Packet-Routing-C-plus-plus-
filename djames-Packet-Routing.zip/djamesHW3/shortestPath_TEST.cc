#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include "readGraph.h"
#include "shortestPath.h"

using namespace std;

TEST_CASE("TESTING SHORTEST PATH")
{
   
  
  SECTION("Matrix dijksta")
    {
      ifstream fin("graph_network.txt");
      double**matrix;
      string* vLabels;
      string**eLabels;
      int vCount=readGraph(fin,matrix,vLabels,eLabels);
      double* dist;
      int* prev;
      dijkstra(matrix,vCount,0,dist,prev);
      REQUIRE(dist[0]==0);
      REQUIRE(dist[1]==4.5);
      REQUIRE(dist[2]==10.0);
      REQUIRE(dist[3]==3.2);
      REQUIRE(dist[4]==0.0);     
      REQUIRE(prev[0]==-1);
      REQUIRE(prev[1]==3);
      REQUIRE(prev[2]==1);
      REQUIRE(prev[3]==0);
      
      for (int i=0;i<vCount;i++)
	{
	  delete [] matrix[i];
	  delete [] eLabels[i];	  
	}
      delete [] prev;
      delete [] dist;
      delete [] vLabels;
      delete [] matrix;
      delete [] eLabels;
      
    }
  SECTION("getPath")
    {
      double* dist;
      int* prev;
      int* path;
      ifstream fin("graph_network.txt");
      double**matrix;
      string* vLabels;
      string**eLabels;
      int vCount=readGraph(fin,matrix,vLabels,eLabels);
      dijkstra(matrix,vCount,0,dist,prev);
      int pathSize=getPath(0,3,prev,path);
      for (int j=0;j<2;j++)
	{
	  cout<<path[j]<<endl;
	}
      REQUIRE(pathSize==2);


      delete [] dist;
      delete [] prev;
      delete [] path;
      for (int i=0;i<vCount;i++)
	{
	  delete [] matrix[i];
	  delete [] eLabels[i];	  
	}
      delete [] vLabels;
      delete [] matrix;
      delete [] eLabels;
      
    }
  SECTION("Adjacency List Dijkstra")
    {
      ifstream fin("graph_network.txt");
      int** adj;
      double** weights;
      int * lengths;
      string* vLabels;
      string** eLabels;
      
      int vCount=readGraph(fin,adj,weights,lengths,vLabels,eLabels);
      double * dist;
      int * prev;
      dijkstra(adj,weights,lengths,vCount,0,dist,prev);
      REQUIRE(dist[0]==0);
      REQUIRE(dist[1]==4.5);
      REQUIRE(dist[2]==10.0);
      REQUIRE(dist[3]==3.2);
      REQUIRE(dist[4]==0.0);     
      REQUIRE(prev[0]==-1);
      REQUIRE(prev[1]==3);
      REQUIRE(prev[2]==1);
      REQUIRE(prev[3]==0);
      
      for (int i=0;i<vCount;i++)
	{
	  delete [] adj[i];
	  delete [] eLabels[i];	  
	}
      delete [] prev;
      delete [] dist;
      delete [] vLabels;
      delete [] adj;
      delete [] eLabels;
    }
 
}
