
#include <iostream>
#include <limits>
#include <vector>
#include <thread>


using namespace std;

void initialize(int start, int end, double * dist, int* prev, bool* inTree, int numThreads)
{
  if (numThreads==1)
    {
      for (int i=start;i<end;i++)
	{
	  dist[i]=numeric_limits<double>::infinity();
	  prev[i]=-1;
	  inTree[i]=false;
	}
    }
  else
    {
      int mid=(end+start)/2;
      thread otherThread(initialize,mid, end, dist, prev, inTree, numThreads/2);
      initialize(start,mid,dist,prev,inTree,numThreads-(numThreads/2));
      otherThread.join();
    }
} 
void getMinVertex(int start, int end, const double* dist, const bool* inTree, int numThreads, int* minVert)
{
  if(numThreads==1)
    {
      double minDist=numeric_limits<double>::infinity();
      *minVert=-1;
      for (int i=start;i<end;i++)
	{
	  if (inTree[i]==false && *minVert==-1)
	    {
	      *minVert=i;
	      minDist=dist[i];
	    }
	  if (dist[i]<minDist && inTree[i]==false)//switch order
	    {
	      *minVert=i;
	      minDist=dist[i];
	    }
	}
    }
  else
    {
      {
	int mid=(end+start)/2;
	int otherMinVertex;
	int myMinVertex;
	thread otherThread(getMinVertex,mid, end, dist, inTree, numThreads/2, &otherMinVertex);
	getMinVertex(start,mid,dist,inTree,numThreads-(numThreads/2),&myMinVertex);
	otherThread.join();
	if(otherMinVertex==-1)
	  {
	    *minVert=myMinVertex;
	    return;
	  }
	else if(myMinVertex==-1)
	  {
	    *minVert=otherMinVertex;
	    return;
	  }
	if (dist[otherMinVertex]<dist[myMinVertex])
	  {
	    *minVert=otherMinVertex;
	  }
	else 
	  {
	    *minVert=myMinVertex;
	  }
      }
    }
}

void updateDistances(int start, int end, const double* const * adjMatrix, int vert, double* dist, int* prev, const bool* inTree, int numThreads)
{
  if (numThreads==1)
    {
      for (int i=start;i<end;i++)
	{
	  if(inTree[i]==false && dist[i]>dist[vert]+adjMatrix[vert][i])
	    {
	      dist[i]=dist[vert]+adjMatrix[vert][i];
	      prev[i]=vert;
	    }
	}
    }
  else
    {
      int mid=(end+start)/2;
      thread otherThread(updateDistances,mid, end, adjMatrix, vert,dist, prev, inTree, numThreads/2);     
      updateDistances(start,mid,adjMatrix,vert, dist, prev, inTree,numThreads-(numThreads/2));
      otherThread.join();
    }
}

void dijkstra(const double* const * adjMatrix, int numVertices, int source, double*& dist, int*& prev, int numThreads)
{
  dist = new double[numVertices];
  prev = new int[numVertices];
  bool* inTree = new bool[numVertices];
   initialize(0, numVertices, dist, prev, inTree, numThreads);
   
   dist[source] = 0;
   for(int i = 1; i < numVertices; i++)
     {
       int vert = -1;
       getMinVertex(0, numVertices, dist, inTree, numThreads, &vert);
       
       inTree[vert] = true;
       updateDistances(0, numVertices, adjMatrix, vert, dist, prev, inTree, numThreads);
       
   }
   delete[] inTree;
}


int getPath(int source, int dest, const int* prev, int*& path)
{
   vector<int> reversePath;
   int v = dest;
   while(v != source && v != -1)
   {
      reversePath.push_back(v);
      v = prev[v];
   }

   if(v == -1)
     {
       //printf("No Path Exists\n");
     }
  

   path = new int[reversePath.size()+1];
   path[0] = source;
   for(unsigned i = 1; i <= reversePath.size(); i++)
   {
      path[i] = reversePath[reversePath.size() - i];
   }

   return reversePath.size()+1;
}
