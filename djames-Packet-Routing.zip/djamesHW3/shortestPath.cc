#include <string>
#include <iostream>
#include <fstream>
#include <limits>
#include <vector>
#include "readGraph.h"
#include <thread>

using namespace std;

void dijkstra(const double* const * matrix, int numVertices, int source, double*& dist, int*& prev)
{
  dist=new double[numVertices];
  prev=new int[numVertices];
  bool * inTree= new bool[numVertices];
  for (int i=0;i<numVertices;i++)
    {
      dist[i]=numeric_limits<double>::infinity();
      prev[i]=-1;
      inTree[i]=false;
    }
  dist[source]=0;
  int node=source;
  int nextNodeInPath=-1;
   
  double curMin=numeric_limits<double>::infinity();
  for(int i=0; i<numVertices;i++)
    {
      int minVert=-1;
      double curMin=numeric_limits<double>::infinity();
      for(int j=0;j<numVertices;j++)
	{
	  if (inTree[j]==false && dist[j]<=curMin)
	    {
	      curMin=dist[j];
	      minVert=j;
	    }
	}
      inTree[minVert]=true;
      for (int k=0;k<numVertices;k++)
	{
	  double weight=matrix[minVert][k];
	  if (dist[k]>dist[minVert]+weight)
	    {
	      dist[k]=dist[minVert]+weight;
	      prev[k]=minVert;
	    }
	}
    }
  delete[] inTree;
}

  


int getPath(int source, int dest, const int* prev, int*& path)
{
  vector<int> reversePath;
  int v = dest;
  while(v != source)
    {
      reversePath.push_back(v);
      v = prev[v];
    }
  
  path = new int[reversePath.size()+1];
  path[0] = source;
  for(unsigned i = 1; i <= reversePath.size(); i++)
    {
      path[i] = reversePath[reversePath.size() - i];
    }
  return reversePath.size()+1;
}
/*
  int i=0;
  int v=dest;
  vector<int> temp;
  
  while( v!= source)
    {
      temp.push_back(v);
      v=prev[v];
    }
  path=new int[temp.size()+1];

  path[0]=source;

  for (int j=1; j<=temp.size();j++)
    {
      path[j]=temp[temp.size()-j];
           
    }

  return temp.size()+1;
  
}
*/





void dijkstra(const int* const * adj, const double* const * weights,const int* lengths, int numVertices, int source, double*& dist, int*&prev)
{
  dist=new double[numVertices];
  prev=new int[numVertices];
  bool * inTree= new bool[numVertices];
  for (int i=0;i<numVertices;i++)
    {
      dist[i]=numeric_limits<double>::infinity();
      prev[i]=-1;
      inTree[i]=false;
    }
  dist[source]=0;
  int node=source;
  int nextNodeInPath=-1; 
  
  double curMin=numeric_limits<double>::infinity();
  for(int i=0; i<numVertices;i++)
    {
      int minVert=-1;
      double curMin=numeric_limits<double>::infinity();
      for(int j=0;j<numVertices;j++)
	{
	  if (inTree[j]==false && dist[j]<=curMin)
	    {
	      curMin=dist[j];
	      minVert=j;
	    }
	}
      inTree[minVert]=true;
      for (int k=0;k<lengths[minVert];k++)
	{
	  int index=adj[minVert][k];
	  double weight=weights[minVert][k];
	  if (dist[index]>dist[minVert]+weight)
	    {
	      dist[index]=dist[minVert]+weight;
	      prev[index]=minVert;
	    }
	}
    }
}


void relax(int u, int v, double weight, double*& dist,int*& prev)
{
  if (dist[v]>dist[u]+weight)
    {
      dist[v]=dist[u]+weight;
      prev[v]=u;
       
      //cout<<(sizeof(prev)/sizeof(prev))<<endl;
    }
}
int bellmanFord(const int* const * edges, const double* weights,int numVertices, int numEdges, int source, double*& dist, int*& prev)
{
  
  dist=new double[numVertices];
  prev=new int[numVertices];
  dist[source]=0;
  for(int w=0;w<numVertices;w++)
    {
      prev[w]=-1;
    }
	       
  for(int i=1; i<numVertices;i++)
    {
      dist[i]=numeric_limits<double>::infinity();
    }

  for (int j=0; j<numVertices-1; j++)
   {
      
      for (int k=0;k<numEdges;k++)
	{ 
	  int u=edges[k][0];
	  int v=edges[k][1];
	  double weight=weights[k];
	  relax(u,v,weight,dist, prev);
	}
    }
 
  for (int l=0;l<numEdges;l++)
    {
      int x=edges[l][0];
      int y=edges[l][1];
      double weight=weights[l];
     
      if (dist[y]>dist[x]+weight)
        
	{
	  return y;
	}
    }
  
  return -1;
}

// vertex is the vertex returned by bellman ford algorithm
int getCycle(int vertex, const int* prev, int numVertices, int*&cycle)
{
  
  int v=prev[vertex];
  vector<int> temp;
  while( v!= vertex)
    {
      temp.push_back(v);
      v=prev[v];
    }
  cycle=new int[temp.size()+1];
  cycle[0]=vertex;
  for (unsigned int j=1; j<=temp.size();j++)
    {
      cycle[j]=temp[temp.size()-j];
      
    }

  return temp.size()+1;
}

