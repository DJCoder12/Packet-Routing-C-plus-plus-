#include <iostream>
#include <string>
#include <fstream>
#include <climits>
#include <cmath>
#include<chrono>
#include "readGraph.h"
#include "shortestPath.h"

using namespace std;

int main(int argc, char**argv)
{
  if(argc<4)
    {
      cout<<"There are not enough arguments to carry out the program"<<endl;
      cout<<"The following should be supplied in this order: name of file containing graph, name of output file, source/start point, and destination/ end point"<<endl;
      return 0;
    } 
  ifstream fin(argv[1]);
  ofstream fout(argv[2]);
  string sourceStr=argv[3];
  string destStr=argv[4];
  int source=sourceStr[6]-48;
  int dest=destStr[6]-48;
  //cout<<source<<endl;
  //cout<<dest<<endl;
  
  
  
  double**matrix;
  string**eLabels;
  double*dist;
  int* prev;
  int* path;
  string* vLabels;
  int vCount= readGraph(fin,matrix,vLabels,eLabels);

  auto start = chrono::system_clock::now();
  dijkstra(matrix,vCount,source,dist,prev);
  auto end = chrono::system_clock::now();
  auto dur = end - start;
  auto durNS = chrono::duration_cast<chrono::nanoseconds>(dur);
  int pathSize=getPath(source,dest,prev,path);
  
  fout<<vCount;
  fout<<" ";
  fout<<(sizeof(eLabels)/sizeof(eLabels))<<endl;
  fout<<"Runtime: "<<double(durNS.count())<<" nanoseconds"<<endl;
  int acc=0;
  for (int i=0;i<vCount;i++)
    {
      fout<<"Router";
      fout<<acc<<endl;
      acc++;
    }
  cout<<(sizeof(path)/sizeof(path))<<endl;
  for (int j=0;j<(sizeof(path)/sizeof(path));j++)
    {
      fout<<path[j];
      fout<<" ";
      fout<<path[j+1];
      fout<<" ";
      fout<<matrix[path[j]][path[j+1]];
      fout<<" ";
      fout<<eLabels[path[j]][path[j+1]];
      

    }
  return 0;
  
 
}
// copy stuff from test to this file
//finish this
