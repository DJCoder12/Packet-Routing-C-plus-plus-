#ifndef BINARY_HEAP
#define BINARY_HEAP


#include <string>
#include <iostream>


using namespace std;

class BinaryHeap
{
  protected:
   int* heap;
   double* priorities;
   int* pos;
   int numItems;

   void heapify(int pos);
   void swap(int pos1, int pos2);

  public:
   BinaryHeap(const double* priorities, int numItems);
   ~BinaryHeap();
   
   int getMin() const;
   void popMin();
   void swap();
   bool contains(int item) const;
   
   double getPriority(int item) const;
   void decreasePriority(int item, double newPriority);
   
   int getSize() const;
   int getItem(int pos) const;
   int getPos(int item) const;
}; 

#endif
