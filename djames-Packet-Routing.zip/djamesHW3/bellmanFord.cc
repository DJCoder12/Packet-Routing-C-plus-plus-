#include <string>
#include <iostream>
#include <fstream>
#include <limits>
#include "readGraph.h"
#include "shortestPath.h"
#include <chrono>
#include <vector>
using namespace std;

int main(int argc, char**argv)
{
  if(argc<4)
    {
      cout<<"There are not enough arguments to carry out the program"<<endl;
      cout<<"The following should be supplied in this order: name of file containing graph, name of output file, a source/start point, and a destination" <<endl;
      return 0;
    } 
  ifstream fin(argv[1]);
  ofstream fout(argv[2]);
  int source=atoi(argv[3]);//sourceStr[6]-48;
  int dest=atoi(argv[4]);//destStr[6]-48;
  
  int** edges;
  double* weights;
  int numVertices;
  int numEdges;
  
  double * dist;
  string * eLabels;
  string * vLabels;
  int * prev;
  int * cycle;
  
  numVertices=readGraph(fin, edges, weights, numEdges, vLabels, eLabels);
  //make sure the size of everything is initialized at the begininning of belman ford
  auto start = chrono::system_clock::now();
  int vertex=bellmanFord(edges, weights, numVertices, numEdges,source, dist, prev);
  
  auto end = chrono::system_clock::now();
  auto dur = end - start;
  auto durNS = chrono::duration_cast<chrono::nanoseconds>(dur);
  //cout<<vertex<<endl;
  
  int *path;
  
  
  
  
  if(vertex!=-1)
    {
      //cout<<"There is a negative cycle present in this graph"<<endl;
      
      //cout<<vertex<<endl;
      int cdetector=getCycle(vertex, prev, numVertices, cycle);
      if(cdetector!=-1)
	{
	  fout<<"negative cycle detected!"<<endl;
	  fout<<"the total weight is " <<weights[vertex]<<endl;
	  fout<<"Runtime: "<<double(durNS.count())<<" nanoseconds"<<endl;
	  fout<<numVertices<<" " <<cdetector<<endl;
	  for (int a=0;a<numVertices;a++)
	    {
	      fout<<vLabels[a]<<endl;
	    }
	  int e=0;
	  while(e!=cdetector)
	    {
	      for (int y=0;y<numEdges;y++)
		{
		  if (edges[y][0]==cycle[e]&&edges[y][1]==cycle[e+1])
		    {
		      cout<<eLabels[y]<<endl;
		      fout<<cycle[e]<<" "<<cycle[e+1]<<" "<<weights[y]<<" "<<eLabels[y]<<endl;
		    }		  
		}
	      //cout<<cycle[e]<<endl;
	      e++;
	    }
	}
    }
  else
    {
      //Make the appropriate string changes you get are printing out the path
      int pathSize=getPath(source,dest, prev,path);
      {
	fout<<"no negative cycle detected"<<endl;
	double pathWeight;
	for (int u=0; u<pathSize;u++)
	  {
	    pathWeight+=path[u];
	  }
	fout<<"the total weight is " <<pathWeight<<endl;
	fout<<"Runtime: "<<double(durNS.count())<<" nanoseconds"<<endl;
	fout<<numVertices<<" " <<numEdges<<endl;
	for (int a=0;a<numVertices;a++)
	  {
	    fout<<vLabels[a]<<endl;
	  }
	int e=0;
	while(e!=pathSize)
	  {
	    for (int y=0;y<pathSize-1;y++)
	      {
		fout<<path[y]<<" "<<path[y+1]<<" "<<endl;	  
	      }
	    
	    e++;
	  }
      }
      
      
      delete [] dist;
      delete [] eLabels;
      delete [] vLabels;
      delete [] weights;
      delete [] prev;
      delete [] cycle;
      delete [] path;
      for (int i=0; i<numEdges;i++)
	{
	  delete [] edges[i];
	}
      delete []edges;
      return 0; 
    }
}


  
 

// return 0;
//}


