#include <string>
#include <ostream>
#include <cmath>
#include "BinaryHeap.h"
#include <iostream>
#include <climits>

using namespace std;
// your binary heap should have 3 arrays. Array is your priorities which is given. Array 2 is your heap which contains the numbers generated to represent if you you were building a binary tree from the priorities given. Array 3 is the index/position

/*
  priorities[1.0,3.0, 2.0]
  heap[1,0,2]
  pos[0,1,2]
  this is position after heapify
  pos[1,0,2]

  get min should return the smallest priority value 
  pop min should also be considered crucial
  heapify is significant
 */


/*
QUESTIONS

In the popMin, decreasePriority function dont I want to shift all entries over one unit to the left.

What is meant by the change for getPriority function. Should this function return the updated priority or the former one?

 */




BinaryHeap::BinaryHeap(const double* priorities, int numItems)
{
   this->numItems = numItems;
   heap = new int[numItems];
   this->priorities = new double[numItems];
   pos = new int[numItems];

   for(int i=0;i<numItems;i++)
   {
      heap[i] = i;
      pos[i] = i;
      this->priorities[i] = priorities[i];
   }

   for(int i=numItems/2; i>=0;i--)
   {
      heapify(i);
   }
}

BinaryHeap::~BinaryHeap()
{
   delete[] heap;
   delete[] priorities;
   delete[] pos;
}

int BinaryHeap::getMin() const
{
   return heap[0];
}

void BinaryHeap::swap(int pos1, int pos2)
{
   int tmp = heap[pos1];
   heap[pos1]=heap[pos2];
   heap[pos2]=tmp;
   
   pos[heap[pos1]]=pos1;
   pos[heap[pos2]]=pos2;
}

void BinaryHeap::heapify(int pos)
{
   int left=2*pos+1;
   int right = 2*pos + 2;
   int smaller;
   if(right < numItems && priorities[heap[pos]] > priorities[heap[right]])
   {
      smaller = right;
   }
   else
   {
      smaller = pos;
   }

   if(left < numItems && priorities[heap[smaller]] > priorities[heap[left]])
   {
      smaller = left;
   }

   if(smaller != pos)
   {
      swap(pos,smaller);      
      heapify(smaller);
   }
}

void BinaryHeap::popMin() 
{
   pos[heap[0]] = -1;
       
   heap[0] = heap[numItems - 1];
   pos[heap[0]] = 0;
       
   numItems--;

   heapify(0);
}

bool BinaryHeap::contains(int item) const
{
  if (item>numItems)
    {
      return false;
    }
  else if(item<0)
    {
      return false;
    }
  else 
    {
      return true;
    }
}

double BinaryHeap::getPriority(int item) const
{
   return priorities[item];
}

void BinaryHeap::decreasePriority(int item, double newPriority)
{
   if(newPriority < priorities[item])
   {
      priorities[item] = newPriority;

      int i = pos[item];
      int parent = (i - 1)/2;
      while(i > 0 && priorities[heap[parent]] > priorities[heap[i]])
      {
	 swap(i, parent);
	 
	 i = parent;
	 parent = (i - 1)/2;
      }   
   }
}

int BinaryHeap::getSize() const
{
   return numItems;
}

int BinaryHeap::getItem(int pos) const
{
   return heap[pos];
}

int BinaryHeap::getPos(int item) const
{
   return pos[item];
}

/*


BinaryHeap::BinaryHeap(const double* priorities, int numItems)
{
  
  double * heap= new double[numItems];
  int * pos= new int[numItems];
  for (int i=0;i<numItems;i++)
    {
      
      heap[i]=priorities[i];
      pos[i]=i;
    }
    for (int r=0;r<5;r++)
    {
      cout<<pos[r]<<endl;
    }
  for (int j=numItems/2;j>=0;j--)
    {
      heapify(j);
      
    }
  
}


// heapify can always be called to organize your heap through all functions.

void BinaryHeap::heapify(int i)
{

  while(i!=0)
    {
      
      if(this->heap[i]<this->heap[i/2])
	{
	  double temp=heap[i/2];
	  cout<<"step 1 failed"<<endl;

	  heap[i/2]=heap[i];
	  cout<<"step 2"<<endl;

	  heap[i]=temp;
	  cout<<"step 3"<<endl;
	  
	  int tempPos=pos[i];
	  cout<<"step 4"<<endl;

	  pos[i]=pos[i/2];
	  cout<<"step 5"<<endl;

	  pos[i/2]=tempPos;
	  cout<<"step 6"<<endl;
	  
	  i=i/2;
	}
      else
	{
	  return;
	}
    }
}

	  int tempPos=pos[i/2];
	  cout<<tempPos<<endl;

	  cout<<"step 4"<<endl;
	  pos[i/2]=pos[i];

	  cout<<"step 5"<<endl;
	  pos[i]=tempPos;

	  cout<<"step 6"<<endl;
	  i=i/2;
	  

BinaryHeap::~BinaryHeap()
{
  delete [] heap;
  delete [] pos;
  
}











//– Returns the item with the minimum priority, but does not alter the heap. Must run in O(1) time.
int BinaryHeap:: getMin() const
{
  return this->heap[1];
}


//– Removes the minimum element from the heap. Must run in O(log n) time.
void BinaryHeap::popMin() 
{
  this->heap[1]=this->heap[numItems];
  this->numItems=this->numItems-1;
  heapify(this->numItems);
}

//– Returns true if item is in the heap. Must be O(1).
bool BinaryHeap:: contains(int item) const
{
  int location=this->pos[item];
  if (this->heap[location]>0)
    {
      return true;
    }
  else
    {
      return false;
    }
}

// – Returns the priority of the given item. Note that this priority might have changed since the heap was created (see below). Must execute in O(1) time.
double BinaryHeap:: getPriority(int item) const
{
  return this->priorities[item];
}


//– If the item is not in the heap, or the new priority is greater than or equal to the priority associated with item, donothing. Otherwise, change the priority of the item and fix the heap accordingly. Must execute in O(log n) time.
void BinaryHeap::decreasePriority(int item, double newPriority)
{
  if(this->priorities[item]>newPriority)
    {
      this->priorities[item]=newPriority;
    }
  heapify(item);
  return; 
}



//– Returns the number of items currently in the heap. Must be O(1).
int BinaryHeap::getSize() const
{
  return this->numItems;
}


//– Mainly for testing/debugging. Returns the item at the given position in the heap (so, h.getItem(0) should be equivalent to h.getMin()). Must be O(1).
int BinaryHeap::getItem(int pos) const
{
  return this->heap[pos];
}



//– Mainly for testing/debugging. Returns the position of the given item in the heap (so, for instance h.getPos(h.getMin()) should return 0). Must be O(1).
int BinaryHeap:: getPos(int item) const 
{
  
  return this->pos[item];
}


*/
