#include <iostream>
#include <string>
#include <fstream>
#include <climits>
#include <cmath>
#include<chrono>
#include<vector>
#include "readGraph.h"
#include "shortestPath.h"

using namespace std;


  //THE FOLLOWING IS THE SAME AS THE CODE FROM READGRAPH FOR THE ADJACENCY LIST
int readGraph(ifstream& fin, int**& adj, double**& weights, int*& lengths, string*& vLabels, string**& eLabels)
{
  int numVertices;
  fin >> numVertices;
  int numEdges;
  fin >> numEdges;
  
  vLabels = new string[numVertices];
  for(int i = 0; i < numVertices; i++)
    {
      fin >> vLabels[i];
    }
  
  adj = new int*[numVertices];
  weights = new double*[numVertices];
  lengths = new int[numVertices];
  eLabels = new string*[numVertices];
  
  int sourceV;
  fin >> sourceV;
  for(int i = 0; i < numVertices; i++)
   {
     vector<int> tmpAdj;
     vector<double> tmpWeights;
     vector<string> tmpLabels;
     
     lengths[i] = 0;
     while(!fin.eof() && sourceV == i)
       {
	 int destV;
	 fin >> destV;
	 tmpAdj.push_back(destV);
	 double w;
	 fin >> w;
	 tmpWeights.push_back(w);
	 string label;
	 fin >> label;
	 tmpLabels.push_back(label);
	 lengths[i]++;
	 fin >> sourceV;
       }
     
     adj[i] = new int[lengths[i]];
     weights[i] = new double[lengths[i]];
     eLabels[i] = new string[lengths[i]];
     for(int j = 0; j < lengths[i]; j++)
       {
	 adj[i][j] = tmpAdj[j];
	 weights[i][j] = tmpWeights[j];
	 eLabels[i][j] = tmpLabels[j];
       }
   }
  
  return numVertices;
}
