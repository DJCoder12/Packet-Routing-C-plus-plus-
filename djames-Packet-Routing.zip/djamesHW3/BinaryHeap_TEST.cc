#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include "BinaryHeap.h"
using namespace std;

TEST_CASE("TESTING Binary Heap")
{
   
  
  SECTION("Binary Heap Init")
    {
      double * priorities= new double[5];
      priorities[0]=1.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=4.0;
      priorities[4]=5.0;
     
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
     
      REQUIRE(heap.getMin()==0);      
    }
  SECTION("getMin")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      REQUIRE(heap.getMin()==1);
    }
  SECTION("POP MIN")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      heap.popMin();
      REQUIRE(heap.getSize()==4);    	
    }
  SECTION("Contains")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      REQUIRE(heap.contains(3)==true);
      REQUIRE(heap.contains(8)==false);
    }
  SECTION("GET Priority")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      REQUIRE(heap.getPriority(0)==22.0);
    }
  SECTION("DECREASE Priority")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      heap.decreasePriority(0, 10.0);
      REQUIRE(heap.getPriority(0)==10.0);
      heap.decreasePriority(0,22.0);
      REQUIRE(heap.getPriority(0)==10.0);
    }
  SECTION("GET SIZE")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      REQUIRE(heap.getSize()==5);
      heap.popMin();
      REQUIRE(heap.getSize()==4);
    }
  SECTION ("GET ITEM")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      REQUIRE(heap.getItem(3)==3);
    }
  SECTION("GET POS")
    {
      double * priorities=new double[5];
      priorities[0]=22.0;
      priorities[1]=2.0;
      priorities[2]=3.0;
      priorities[3]=7.0;
      priorities[4]=5.0;
      int numItems=5;
      BinaryHeap heap(priorities,numItems);
      REQUIRE(heap.getPos(1)==0);
    }
}
