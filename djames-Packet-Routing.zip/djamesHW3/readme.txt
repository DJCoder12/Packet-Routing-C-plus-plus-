Donovan James
CPS222 Project 3

Files Submitted:

readGraph.h/readGraph.cc/readGraph_TEST.cc= This program reads an external text file and generates/fills the collection using the information from the text file. The first function fills a matrix. The second function creates and fills and adjacency list. The third function generates and fills an edge list.All of these functions return the number of vertices given.


shortestPath.h/shortestPath.cc/shortestPath_TEST.cc= This program contains  2 implementations of dijkstra's algorithm. The first one uses dijkstra's algorithm on a matrix and the second one implements dijkstra's algorithm on a adjacency list. The bellmanFord Algorithm is implemented on an edgeList in hopes of finding the shortest path in a given graph. The getCycle function finds the vertices that are part of a cycle that are present in a graph.

BinaryHeap.h/BinaryHeap.cc/BinaryHeap_TEST-This creates the Binary Heap Class and uses the 3 arrays for its implementation to find minimum entries and function like a Binary Heap.

parallelDijkstra.cc= This program contains  a function that finds the shortest path in a graph using parallel programming.

bellmanFord.cc- This is a main file that tests my bellman ford algorithm. It also tests my getCycle function which determines the path of a negative cycle within my graph.

matrixDijkstra= a main file that tests if the adjacency matrix is made and that the is is written to an outfile.

listDijkstra= a main file that tests if the adjacency list is made and that it is written to an outfile.

Known Issues:
My analysis and my listDijkstra may be wrong.
